# In this file we define the functions that is highly related by their purposes and it's behave similarly 
# so we put them together in this file, in other file we will import this file and then we can use that function...
# this is called modulation or module file
def cacl_tax():
    pass

def calc_shipping():
    pass